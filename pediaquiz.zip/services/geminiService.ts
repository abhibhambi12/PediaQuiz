import { GoogleGenAI, Type } from "@google/genai";
import { MCQ } from '../types';

/**
 * A robust JSON parser that extracts a JSON string from a larger text block
 * (e.g., one that includes markdown fences or conversational text) and parses it.
 * @param text The raw text response from the AI.
 * @returns The parsed JSON object.
 */
const cleanAndParseJson = (text: string): any => {
    // Find the first occurrence of '{' or '['
    const firstBracket = text.indexOf('[');
    const firstBrace = text.indexOf('{');
    let startIndex = -1;

    if (firstBracket === -1) {
        startIndex = firstBrace;
    } else if (firstBrace === -1) {
        startIndex = firstBracket;
    } else {
        startIndex = Math.min(firstBracket, firstBrace);
    }
    
    if (startIndex === -1) {
        throw new Error("Response is not valid JSON and no JSON block was found.");
    }

    // Find the last occurrence of '}' or ']'
    const lastBracket = text.lastIndexOf(']');
    const lastBrace = text.lastIndexOf('}');
    const endIndex = Math.max(lastBracket, lastBrace);

    if (endIndex === -1 || endIndex < startIndex) {
         throw new Error("Response is not valid JSON and no JSON block was found.");
    }

    const jsonString = text.substring(startIndex, endIndex + 1);
    try {
        return JSON.parse(jsonString);
    } catch (e: any) {
        // Provide more context in the error message
        console.error("Failed to parse extracted JSON string:", jsonString);
        throw new Error(`Failed to parse JSON: ${e.message}`);
    }
};

const getAiClient = () => {
    // Per guidelines, the API key must be available as process.env.API_KEY.
    if (!process.env.API_KEY) {
        // This check is for developer convenience; the execution environment must provide the key.
        throw new Error("API_KEY environment variable not set.");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const extractMCQsFromPDF = async (pdfBase64: string, chapterId: string): Promise<Partial<MCQ>[]> => {
    const ai = getAiClient();
    const pdfPart = {
        inlineData: { mimeType: 'application/pdf', data: pdfBase64 },
    };
    const textPart = {
        text: `Extract all multiple-choice questions (MCQs) from this document. The chapter ID for all extracted MCQs should be '${chapterId}'. Return the data in the specified JSON format.`,
    };
    const responseSchema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                question: { type: Type.STRING },
                optionA: { type: Type.STRING },
                optionB: { type: Type.STRING },
                optionC: { type: Type.STRING },
                optionD: { type: Type.STRING },
                correctAnswer: { type: Type.STRING, enum: ['A', 'B', 'C', 'D'] },
                explanation: { type: Type.STRING },
            },
            required: ["question", "optionA", "optionB", "optionC", "optionD", "correctAnswer"],
        },
    };

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [pdfPart, textPart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            },
        });

        // Use the robust parser to handle potential formatting issues in the response text.
        const extractedData = cleanAndParseJson(response.text);
        
        if (!Array.isArray(extractedData)) {
             throw new Error("AI response was not in the expected array format.");
        }

        return extractedData.map((item: any) => ({ ...item, chapterId, tags: 'pdf-import' }));

    } catch (error) {
        console.error("Error extracting MCQs with Gemini:", error);
        throw new Error("Failed to extract MCQs from PDF. The AI model might have had trouble with the document format or content.");
    }
};
