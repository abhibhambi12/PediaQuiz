
import { AppData, Topic, Chapter, MCQ, DebugData } from '../types';

const SHEET_ID = '1p7hQaFsKCi5Ot2zNOeJFtqvCuDdd2DDEkoDhC2Yw1no';
const TOPICS_SHEET_NAME = 'Topics';
const MCQ_SHEET_NAME = 'MasterMCQ';

const TOPICS_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${TOPICS_SHEET_NAME}`;
const MCQ_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${MCQ_SHEET_NAME}`;
const CACHE_KEY = 'mcqAppData';


// --- Caching ---
export const loadDataFromCache = (): AppData | null => {
  try {
    const cachedData = localStorage.getItem(CACHE_KEY);
    return cachedData ? JSON.parse(cachedData) : null;
  } catch (error) {
    console.error("Error loading data from cache:", error);
    clearCache(); // Clear corrupted cache
    return null;
  }
};

export const clearCache = (): void => {
  try {
    localStorage.removeItem(CACHE_KEY);
  } catch (error) {
    console.error("Error clearing cache:", error);
  }
};


// --- Data Fetching and Parsing ---

// Robust CSV parser that IGNORES the sheet's header and uses a predefined one.
const parseCSV = (csv: string, predefinedHeaders: string[]): Record<string, string>[] => {
  const lines = csv.trim().split('\n');
  lines.shift(); // CRITICAL: Remove and discard the (potentially corrupted) header row from the sheet.
  
  if (lines.length === 0) {
    return [];
  }

  const unquote = (field: string) => {
    const trimmed = field ? field.trim() : '';
    return trimmed.startsWith('"') && trimmed.endsWith('"') ? trimmed.slice(1, -1).replace(/""/g, '"') : trimmed;
  };

  const rows: Record<string, string>[] = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    // Regex to split a row into fields, respecting quotes.
    const values = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    const rowObject: Record<string, string> = {};
    predefinedHeaders.forEach((header, index) => {
        rowObject[header] = unquote(values[index] || '');
    });
    rows.push(rowObject);
  }
  return rows;
};

const processData = (topicsData: any[], mcqData: any[]): AppData => {
  const topicsMap = new Map<string, Topic>();
  const chaptersMap = new Map<string, Chapter>();

  topicsData.forEach(row => {
    const chapterId = row.ChapterID ? row.ChapterID.trim() : null;
    const topicId = row.TopicID ? row.TopicID.trim() : null;
    
    if (!topicId || !row.TopicName || !chapterId || !row.ChapterName) return;

    if (!topicsMap.has(topicId)) {
      topicsMap.set(topicId, { id: topicId, name: row.TopicName.trim(), chapters: [] });
    }

    if (!chaptersMap.has(chapterId)) {
      const chapter = { id: chapterId, name: row.ChapterName.trim(), topicId: topicId };
      chaptersMap.set(chapterId, chapter);
      topicsMap.get(topicId)?.chapters.push(chapter);
    }
  });

  const mcqs: MCQ[] = mcqData
    .map((row, index) => {
      const chapterId = row.ChapterID ? row.ChapterID.trim() : null;
      if (!row.Question || !row.Correct_Answer || !chapterId) {
        return null;
      }
      return {
        id: `${chapterId}-${index}`,
        question: row.Question,
        optionA: row.OptionA,
        optionB: row.OptionB,
        optionC: row.OptionC,
        optionD: row.OptionD,
        correctAnswer: row.Correct_Answer.trim() as 'A' | 'B' | 'C' | 'D',
        explanation: row.Explanation,
        chapterId: chapterId,
        tags: row.Tags
      }
    })
    .filter((mcq): mcq is MCQ => mcq !== null);

  return { topics: Array.from(topicsMap.values()), mcqs };
};

export const fetchAndProcessData = async (): Promise<{ processedData: AppData; debugData: DebugData }> => {
  try {
    const [topicsResponse, mcqResponse] = await Promise.all([
      fetch(TOPICS_URL),
      fetch(MCQ_URL),
    ]);

    if (!topicsResponse.ok || !mcqResponse.ok) {
      throw new Error('Failed to fetch data from Google Sheets.');
    }

    const [topicsCsv, mcqCsv] = await Promise.all([
      topicsResponse.text(),
      mcqResponse.text(),
    ]);
    
    // Hardcode the correct headers in the correct order. This makes the parser robust against header corruption.
    const topicHeaders = ["TopicID", "TopicName", "ChapterID", "ChapterName"];
    const mcqHeaders = ["Question", "OptionA", "OptionB", "OptionC", "OptionD", "Correct_Answer", "Explanation", "ChapterID", "Tags"];

    // Parse the data using the predefined headers, ignoring the remote header.
    const topicsData = parseCSV(topicsCsv, topicHeaders);
    const mcqData = parseCSV(mcqCsv, mcqHeaders);
    
    const processedData = processData(topicsData, mcqData);

    localStorage.setItem(CACHE_KEY, JSON.stringify(processedData));

    const debugData = {
        rawTopicsCsv: topicsCsv,
        rawMcqCsv: mcqCsv,
        parsedTopics: topicsData,
        parsedMcqs: mcqData,
    };

    return { processedData, debugData };

  } catch (error) {
    console.error("Error fetching or processing data:", error);
    throw error;
  }
};
