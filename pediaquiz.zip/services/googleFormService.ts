import { MCQ } from '../types';

const GOOGLE_FORM_BASE_URL = 'https://docs.google.com/forms/d/e/1P48VqGnbhSfdbLN2u9yBk5_lTz2kOYo4Rzf_u2X3vFE/formResponse';

const entryIdMap = {
  question: 'entry.196086443',
  optionA: 'entry.2043679065',
  optionB: 'entry.1912100340',
  optionC: 'entry.1500781587',
  optionD: 'entry.773037342',
  correctAnswer: 'entry.1162559973',
  explanation: 'entry.706781798',
  chapterId: 'entry.1412529020',
  tags: 'entry.1709602848',
};

export const generateGoogleFormUrl = (mcq: Partial<MCQ>): string => {
    const url = new URL(GOOGLE_FORM_BASE_URL);
    const appendParam = (key: keyof typeof entryIdMap, value: string | undefined | null) => {
        if (value) {
            url.searchParams.append(entryIdMap[key], String(value));
        }
    };

    appendParam('question', mcq.question);
    appendParam('optionA', mcq.optionA);
    appendParam('optionB', mcq.optionB);
    appendParam('optionC', mcq.optionC);
    appendParam('optionD', mcq.optionD);
    appendParam('correctAnswer', mcq.correctAnswer);
    appendParam('explanation', mcq.explanation);
    appendParam('chapterId', mcq.chapterId);
    appendParam('tags', mcq.tags);
    
    return url.toString();
};