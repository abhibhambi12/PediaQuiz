
export interface MCQ {
  id: string;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  chapterId: string;
  tags: string;
}

export interface Chapter {
  id: string;
  name: string;
  topicId: string;
  mcqCount?: number;
}

export interface Topic {
  id: string;
  name: string;
  chapters: Chapter[];
  chapterCount?: number;
  totalMcqCount?: number;
}

export interface AppData {
  topics: Topic[];
  mcqs: MCQ[];
}

export interface DebugData {
  rawTopicsCsv?: string;
  rawMcqCsv?: string;
  parsedTopics?: any[];
  parsedMcqs?: any[];
}

export interface QuestionResult {
  mcqId: string;
  isCorrect: boolean;
}

export interface QuizResult {
  id: string;
  date: string;
  chapterId: string;
  score: number;
  totalQuestions: number;
  results: QuestionResult[];
}

export type Theme = 'light' | 'dark';

export type AttemptedMCQs = Record<string, { isCorrect: boolean }>;

export interface DataContextType {
  data: AppData | null;
  debugData: DebugData | null;
  loading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
  
  // Progress tracking
  bookmarks: string[];
  toggleBookmark: (mcqId: string) => void;
  quizHistory: QuizResult[];
  addQuizResult: (result: Omit<QuizResult, 'id' | 'date'>) => void;
  attempted: AttemptedMCQs;
  addAttempt: (mcqId: string, isCorrect: boolean) => void;
  resetProgress: () => void;

  // UI
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

// Deprecated, not used in the new design. Kept for type safety if old components were still present.
export type AdminMode = 'manual' | 'bulk' | 'csv' | 'pdf';
