
import React, { useState, useEffect, createContext, useContext, useCallback, useMemo } from 'react';
import { Routes, Route, useParams, useNavigate, Link, useLocation } from 'react-router-dom';
import { MCQ, AppData, Topic, Chapter, DataContextType, DebugData, QuizResult, QuestionResult, AttemptedMCQs, Theme } from './types';
import { fetchAndProcessData, loadDataFromCache, clearCache } from './services/dataService';

// --- CONTEXT ---
const DataContext = createContext<DataContextType | null>(null);
const useData = () => {
    const context = useContext(DataContext);
    if (!context) throw new Error('useData must be used within a DataProvider');
    return context;
};

// --- ICONS ---
const HomeIcon = () => (<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>);
const BookmarkIcon = ({ filled = false }) => (<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={filled ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}> <path strokeLinecap="round" strokeLinejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.5 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z" /> </svg>);
const ChartBarIcon = () => (<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>);
const CogIcon = () => (<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826 3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>);
const ChevronRightIcon = () => (<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>);
const ChevronDownIcon = ({ className }: { className?: string }) => ( <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg> );
const SunIcon = () => (<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" /></svg>);
const MoonIcon = () => (<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" /></svg>);
const BackIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg> );

// --- UI COMPONENTS ---
const Loader = ({ message }: { message: string }) => ( <div className="flex flex-col items-center justify-center h-full min-h-[300px] text-center"> <svg className="animate-spin -ml-1 mr-3 h-10 w-10 text-sky-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"> <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle> <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path> </svg> <p className="mt-4 text-lg font-medium text-slate-500 dark:text-slate-400">{message}</p> </div> );
const StatCard = ({ title, value, colorClass }: { title: string, value: string | number, colorClass?: string }) => (
    <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-lg">
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
        <p className={`text-2xl font-bold mt-1 ${colorClass || 'text-slate-800 dark:text-slate-200'}`}>{value}</p>
    </div>
);
const Header = () => (
    <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm shadow-sm sticky top-0 z-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
                <Link to="/" className="text-2xl font-bold text-sky-600 dark:text-sky-400 tracking-tight">PediaQuiz</Link>
                <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Dr. Abhishek Bhambi</div>
            </div>
        </div>
    </header>
);

const Footer = () => (
    <footer className="text-center py-4 text-xs text-slate-400 dark:text-slate-500">
        Made by Dr. Abhishek Bhambi
    </footer>
);

const BottomNav = () => {
    const location = useLocation();
    const navItems = [
        { path: '/', icon: <HomeIcon />, label: 'Home' },
        { path: '/bookmarks', icon: <BookmarkIcon />, label: 'Bookmarks' },
        { path: '/stats', icon: <ChartBarIcon />, label: 'Stats' },
        { path: '/settings', icon: <CogIcon />, label: 'Settings' },
    ];
    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-t border-slate-200 dark:border-slate-700 z-20">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-4">
                {navItems.map(item => {
                    const isActive = location.pathname === item.path;
                    return (
                        <Link key={item.path} to={item.path} className={`flex flex-col items-center justify-center text-center py-2 transition-colors duration-200 ${isActive ? 'text-sky-500' : 'text-slate-500 hover:text-sky-500'}`}>
                            {item.icon}
                            <span className="text-xs font-medium mt-1">{item.label}</span>
                        </Link>
                    )
                })}
            </div>
        </nav>
    );
};

// --- PAGES ---

const DashboardPage = () => {
    const { data } = useData();
    const [expandedTopics, setExpandedTopics] = useState<Set<string>>(new Set());

    const toggleTopic = (topicId: string) => {
        setExpandedTopics(prev => {
            const newSet = new Set(prev);
            if (newSet.has(topicId)) {
                newSet.delete(topicId);
            } else {
                newSet.add(topicId);
            }
            return newSet;
        });
    };

    if (!data) return <Loader message="Loading topics..."/>

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-200">Study Topics</h1>
            <div className="space-y-3">
                {data.topics.map(topic => {
                    const isExpanded = expandedTopics.has(topic.id);
                    return (
                        <div key={topic.id} className="bg-white dark:bg-slate-800 rounded-xl shadow-sm overflow-hidden transition-all">
                             <button 
                                onClick={() => toggleTopic(topic.id)} 
                                className="w-full text-left p-4 flex justify-between items-center hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                                aria-expanded={isExpanded}
                                aria-controls={`chapters-for-${topic.id}`}
                            >
                                 <div>
                                     <h3 className="font-bold text-lg">{topic.name}</h3>
                                     <p className="text-sm text-slate-500 dark:text-slate-400">{topic.chapterCount} Chapters | {topic.totalMcqCount} MCQs</p>
                                 </div>
                                 <ChevronDownIcon className={`text-slate-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                             </button>
                             {isExpanded && (
                                <div id={`chapters-for-${topic.id}`} className="p-4 border-t border-slate-200 dark:border-slate-700 animate-fade-in">
                                     <ul className="space-y-2">
                                        {topic.chapters.map(chapter => (
                                            <li key={chapter.id}>
                                                <Link to={`/chapter/${chapter.id}`} className="block p-3 rounded-lg bg-slate-50 dark:bg-slate-700/50 hover:bg-sky-100 dark:hover:bg-sky-900/50 transition-colors">
                                                    <div className="flex justify-between items-center">
                                                        <div>
                                                            <p className="font-medium text-slate-700 dark:text-slate-300">{chapter.name}</p>
                                                            <p className="text-sm text-slate-500 dark:text-slate-400">{chapter.mcqCount} MCQs</p>
                                                        </div>
                                                        <ChevronRightIcon />
                                                    </div>
                                                </Link>
                                            </li>
                                        ))}
                                     </ul>
                                </div>
                             )}
                        </div>
                    )
                })}
            </div>
        </div>
    );
};

const ChapterDetailPage = () => {
    const { chapterId } = useParams<{ chapterId: string }>();
    const { data, attempted } = useData();
    const navigate = useNavigate();

    const { chapter, topic, wrongInChapter } = useMemo(() => {
        if (!data || !chapterId) return { chapter: null, topic: null, wrongInChapter: 0 };
        let foundChapter: Chapter | null = null;
        let foundTopic: Topic | null = null;
        for (const t of data.topics) {
            const ch = t.chapters.find(c => c.id === chapterId);
            if (ch) {
                foundChapter = ch;
                foundTopic = t;
                break;
            }
        }
        const wrongInChapter = data.mcqs
            .filter(mcq => mcq.chapterId === chapterId && attempted[mcq.id] && !attempted[mcq.id].isCorrect)
            .length;

        return { chapter: foundChapter, topic: foundTopic, wrongInChapter };
    }, [data, chapterId, attempted]);

    if (!chapter || !topic) return <div>Chapter not found.</div>;

    const ActionButton = ({ to, title, subtitle, disabled = false }: { to: string, title: string, subtitle: string, disabled?: boolean }) => (
        <Link to={to} className={`block text-center p-6 rounded-lg shadow transition ${disabled ? 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed' : 'bg-sky-500 hover:bg-sky-600 text-white'}`}>
             <h2 className="text-xl font-bold">{title}</h2>
             <p className={`mt-1 ${disabled ? 'text-slate-500 dark:text-slate-400' : ''}`}>{subtitle}</p>
        </Link>
    );

    return (
         <div>
            <button onClick={() => navigate('/')} className="flex items-center space-x-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-sky-600 dark:hover:text-sky-400 mb-6">
                <BackIcon />
                <span>Back to Home</span>
            </button>
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6">
                <p className="text-sm text-sky-600 dark:text-sky-400 font-semibold">{topic.name}</p>
                <h1 className="text-3xl font-bold mt-1 mb-2 text-slate-800 dark:text-slate-200">{chapter.name}</h1>
                <p className="text-slate-500 dark:text-slate-400 mb-6">{chapter.mcqCount} questions available</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <ActionButton to={`/session/${chapter.id}/practice`} title="Practice Mode" subtitle="Review with instant feedback" />
                    <ActionButton to={`/session/${chapter.id}/quiz`} title="Quiz Mode" subtitle="Test your knowledge" />
                    <ActionButton to={`/session/${chapter.id}/wrong`} title="Practice Mistakes" subtitle={`${wrongInChapter} incorrect questions`} disabled={wrongInChapter === 0} />
                </div>
            </div>
        </div>
    );
};

const MCQSessionPage = () => {
    // This will be a very large component. I'll sketch it out.
    const { chapterId, mode } = useParams<{ chapterId: string, mode: 'practice' | 'quiz' | 'wrong' }>();
    const { data, bookmarks, toggleBookmark, attempted, addAttempt, addQuizResult } = useData();
    const navigate = useNavigate();

    const [mcqs, setMcqs] = useState<MCQ[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [selectedOption, setSelectedOption] = useState<string | null>(null);
    const [showAnswer, setShowAnswer] = useState(mode === 'practice'); // Show answer immediately in practice mode
    const [answers, setAnswers] = useState<Record<number, string>>({});
    const [isFinished, setIsFinished] = useState(false);
    
    // Slide animation state
    const [slideDirection, setSlideDirection] = useState<'right' | 'left'>('left');

    useEffect(() => {
        if (data) {
            let filteredMcqs: MCQ[] = [];
            if (mode === 'wrong') {
                const wrongMcqIds = Object.entries(attempted)
                    .filter(([_, result]) => !result.isCorrect)
                    .map(([id, _]) => id);
                const wrongSet = new Set(wrongMcqIds);
                filteredMcqs = data.mcqs.filter(mcq => mcq.chapterId === chapterId && wrongSet.has(mcq.id));
            } else { // practice or quiz
                filteredMcqs = data.mcqs.filter(mcq => mcq.chapterId === chapterId);
            }
            setMcqs(filteredMcqs);
        }
    }, [data, chapterId, mode, attempted]);
    
    // Finish Quiz Logic
    useEffect(() => {
        if (isFinished && mode === 'quiz' && chapterId) {
             const score = mcqs.reduce((acc, mcq, index) => acc + (mcq.correctAnswer === answers[index] ? 1 : 0), 0);
             const detailedResults: QuestionResult[] = mcqs.map((mcq, index) => ({
                mcqId: mcq.id,
                isCorrect: mcq.correctAnswer === answers[index],
            }));
            addQuizResult({ chapterId, score, totalQuestions: mcqs.length, results: detailedResults });
        }
    }, [isFinished, mode, addQuizResult, mcqs, answers, chapterId]);

    const handleSelectOption = (option: 'A' | 'B' | 'C' | 'D') => {
        if (mode === 'quiz' && isFinished) return;
        if (mode === 'practice' && showAnswer) return;

        setSelectedOption(option);
        const isCorrect = mcqs[currentIndex].correctAnswer === option;
        addAttempt(mcqs[currentIndex].id, isCorrect);
        
        if(mode === 'practice') {
          setShowAnswer(true);
        } else { // Quiz mode
          setAnswers({ ...answers, [currentIndex]: option });
        }
    };

    const handleNext = () => {
        if (currentIndex < mcqs.length - 1) {
            setSlideDirection('left');
            setCurrentIndex(prev => prev + 1);
            setSelectedOption(mode === 'quiz' ? answers[currentIndex + 1] || null : null);
            setShowAnswer(mode === 'practice');
        } else {
            setIsFinished(true);
        }
    };

     const getOptionStyle = (option: 'A' | 'B' | 'C' | 'D') => {
        const mcq = mcqs[currentIndex];
        const shouldReveal = showAnswer || (mode === 'quiz' && isFinished);
        if (!shouldReveal) {
            return selectedOption === option ? 'bg-sky-200 dark:bg-sky-800 ring-2 ring-sky-500' : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600';
        }
        if (option === mcq.correctAnswer) {
            return 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300 ring-2 ring-green-500';
        }
        if (selectedOption === option && selectedOption !== mcq.correctAnswer) {
            return 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-300 ring-2 ring-red-500';
        }
        return 'bg-slate-100 dark:bg-slate-700';
    };

    if (mcqs.length === 0) {
        return (
            <div className="text-center py-10">
                <h1 className="text-xl font-bold mb-4">No Questions Found</h1>
                <p className="text-slate-500 dark:text-slate-400">There are no questions for this session type.</p>
                <button onClick={() => navigate(`/chapter/${chapterId}`)} className="mt-6 px-6 py-2 rounded-md bg-sky-500 text-white hover:bg-sky-600">Back to Chapter</button>
            </div>
        );
    }
    
    if (isFinished) {
         const score = mcqs.reduce((acc, mcq, index) => acc + (mcq.correctAnswer === answers[index] ? 1 : 0), 0);
         const percentage = mcqs.length > 0 ? Math.round((score / mcqs.length) * 100) : 0;
        return (
             <div className="text-center bg-white dark:bg-slate-800 p-8 rounded-lg shadow-lg">
                <h1 className="text-3xl font-bold">Session Complete!</h1>
                {mode === 'quiz' && (
                    <>
                        <p className="text-5xl font-bold my-4 text-sky-500">{percentage}%</p>
                        <p className="text-xl">You scored {score} out of {mcqs.length}</p>
                    </>
                )}
                <div className="mt-8 flex justify-center gap-4">
                   <button onClick={() => navigate(`/chapter/${chapterId}`)} className="px-6 py-2 rounded-md bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600">Back to Chapter</button>
                </div>
            </div>
        )
    }

    const currentMcq = mcqs[currentIndex];
    const shouldRevealAnswer = (mode === 'practice' && showAnswer);

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-xl font-bold">Q. {currentIndex + 1}/{mcqs.length}</h1>
                {/* Timer can be added here */}
            </div>
            <div className="relative overflow-hidden">
                <div key={currentIndex} className="animate-slide-in-right">
                     <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 relative">
                        <button onClick={() => toggleBookmark(currentMcq.id)} className={`absolute top-4 right-4 p-1 rounded-full transition-colors ${bookmarks.includes(currentMcq.id) ? 'text-amber-500' : 'text-slate-400 hover:text-amber-400'}`} aria-label="Bookmark">
                            <BookmarkIcon filled={bookmarks.includes(currentMcq.id)} />
                        </button>
                        <p className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 pr-10">{currentMcq.question}</p>
                        <div className="space-y-3">
                            {(['A', 'B', 'C', 'D'] as const).map(optionKey => (
                                <button
                                    key={optionKey}
                                    onClick={() => handleSelectOption(optionKey)}
                                    disabled={shouldRevealAnswer || (mode === 'quiz' && selectedOption != null)}
                                    className={`w-full text-left p-4 rounded-lg transition-all duration-200 flex items-start ${getOptionStyle(optionKey)}`}
                                >
                                    <span className="font-bold mr-3">{optionKey}.</span>
                                    <span>{currentMcq[`option${optionKey}`]}</span>
                                </button>
                            ))}
                        </div>
                        {shouldRevealAnswer && (
                            <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/30 rounded-lg border-l-4 border-amber-500 animate-fade-in">
                                <h3 className="font-bold text-amber-800 dark:text-amber-300">Explanation</h3>
                                <p className="mt-2 text-slate-700 dark:text-slate-300">{currentMcq.explanation || 'No explanation provided.'}</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
             <div className="flex justify-end mt-6">
                <button onClick={handleNext} disabled={!selectedOption} className="px-6 py-2 rounded-md bg-sky-500 text-white hover:bg-sky-600 disabled:opacity-50 disabled:cursor-not-allowed">
                    {currentIndex === mcqs.length - 1 ? 'Finish Session' : 'Next'}
                </button>
            </div>
        </div>
    );
};

const BookmarksPage = () => { 
    const { data, bookmarks, toggleBookmark } = useData();

    const bookmarkedMcqs = useMemo(() => {
        if (!data || !bookmarks) return [];
        const bookmarkedSet = new Set(bookmarks);
        return data.mcqs.filter(mcq => bookmarkedSet.has(mcq.id));
    }, [data, bookmarks]);

    if (bookmarkedMcqs.length === 0) {
        return (
            <div className="text-center py-10">
                <h1 className="text-2xl font-bold mb-2">No Bookmarks</h1>
                <p className="text-slate-500 dark:text-slate-400">You haven't bookmarked any questions yet.</p>
            </div>
        )
    }

    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Bookmarked Questions</h1>
            <div className="space-y-4">
                {bookmarkedMcqs.map(mcq => (
                    <div key={mcq.id} className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 relative">
                        <button onClick={() => toggleBookmark(mcq.id)} className="absolute top-4 right-4 p-1 text-amber-500" aria-label="Remove bookmark">
                            <BookmarkIcon filled={true} />
                        </button>
                        <p className="text-lg font-semibold mb-4 pr-10">{mcq.question}</p>
                        <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/30 rounded-lg">
                            <p><strong>Correct Answer: {mcq.correctAnswer}.</strong> {mcq[`option${mcq.correctAnswer}`]}</p>
                        </div>
                        {mcq.explanation && (
                             <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/30 rounded-lg">
                                <h3 className="font-bold text-amber-800 dark:text-amber-300">Explanation</h3>
                                <p className="mt-2 text-slate-700 dark:text-slate-300">{mcq.explanation}</p>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    )
};
const StatsPage = () => {
    const { quizHistory, data, attempted } = useData();

    const stats = useMemo(() => {
        if (!data) return { total: 0, attemptedCount: 0, correctCount: 0, accuracy: 0 };
        const total = data.mcqs.length;
        const attemptedCount = Object.keys(attempted).length;
        const correctCount = Object.values(attempted).filter(a => a.isCorrect).length;
        const accuracy = attemptedCount > 0 ? (correctCount / attemptedCount) * 100 : 0;
        return { total, attemptedCount, correctCount, accuracy };
    }, [data, attempted]);

    const chaptersMap = useMemo(() => {
        if (!data) return new Map();
        return new Map(data.topics.flatMap(t => t.chapters).map(c => [c.id, c.name]));
    }, [data]);

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold">Performance Stats</h1>

             <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm">
                <h2 className="text-xl font-bold mb-4">Overall Progress</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <StatCard title="Total MCQs" value={stats.total} />
                    <StatCard title="Attempted" value={`${stats.attemptedCount} / ${stats.total}`} />
                    <StatCard title="Correct" value={stats.correctCount} colorClass="text-green-500" />
                    <StatCard title="Accuracy" value={`${stats.accuracy.toFixed(1)}%`} colorClass="text-sky-500" />
                </div>
                <div className="mt-4">
                    <p className="text-sm font-medium mb-1">Overall Completion</p>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
                        <div className="bg-sky-500 h-2.5 rounded-full" style={{ width: `${stats.total > 0 ? (stats.attemptedCount / stats.total) * 100 : 0}%` }}></div>
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm">
                 <h2 className="text-xl font-bold mb-4">Quiz History</h2>
                 {quizHistory.length === 0 ? (
                    <div className="text-center py-6">
                        <p className="text-slate-500 dark:text-slate-400">No quiz history yet.</p>
                        <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">Complete a test in 'Quiz Mode' to see your history.</p>
                    </div>
                 ) : (
                    <div className="space-y-3">
                        {[...quizHistory].reverse().map(quiz => {
                            const chapterName = chaptersMap.get(quiz.chapterId) || "Unknown Chapter";
                            const percentage = quiz.totalQuestions > 0 ? Math.round((quiz.score / quiz.totalQuestions) * 100) : 0;
                            return (
                                <div key={quiz.id} className="flex justify-between items-center p-3 rounded-lg bg-slate-100 dark:bg-slate-700/70">
                                    <div>
                                        <p className="font-semibold text-slate-700 dark:text-slate-300">{chapterName}</p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400">
                                            {new Date(quiz.date).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <div className="text-right">
                                        <p className={`font-bold text-lg ${percentage >= 50 ? 'text-green-500' : 'text-red-500'}`}>{percentage}%</p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400">
                                            {quiz.score}/{quiz.totalQuestions}
                                        </p>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                 )}
            </div>
        </div>
    );
};
const SettingsPage = () => {
    const { theme, setTheme, resetProgress, refreshData, debugData } = useData();
    const [showDebug, setShowDebug] = useState(false);

    const handleReset = () => {
        if (window.confirm("Are you sure you want to reset all your progress? This action cannot be undone.")) {
            resetProgress();
        }
    }
    
    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Settings</h1>
            <div className="space-y-6">
                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm">
                    <h2 className="font-bold text-lg mb-2">Appearance</h2>
                    <div className="flex justify-between items-center">
                        <span>Theme</span>
                        <div className="flex items-center space-x-2 p-1 bg-slate-200 dark:bg-slate-700 rounded-full">
                            <button onClick={() => setTheme('light')} className={`p-1.5 rounded-full ${theme === 'light' ? 'bg-white shadow' : ''}`}><SunIcon/></button>
                            <button onClick={() => setTheme('dark')} className={`p-1.5 rounded-full ${theme === 'dark' ? 'bg-slate-800 shadow' : ''}`}><MoonIcon/></button>
                        </div>
                    </div>
                </div>

                 <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm">
                    <h2 className="font-bold text-lg mb-2">Data Management</h2>
                    <div className="space-y-3">
                        <button onClick={refreshData} className="w-full text-left p-3 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">Refresh MCQ Data</button>
                        <button onClick={handleReset} className="w-full text-left p-3 rounded-lg bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors">Reset All Progress</button>
                    </div>
                </div>

                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm">
                     <button onClick={() => setShowDebug(!showDebug)} className="w-full text-left font-bold text-lg">Developer Info</button>
                     {showDebug && debugData && (
                        <pre className="mt-2 p-2 bg-slate-100 dark:bg-slate-700 rounded text-xs overflow-auto max-h-60">
                            {JSON.stringify({
                                topics: debugData.parsedTopics?.length,
                                mcqs: debugData.parsedMcqs?.length,
                            }, null, 2)}
                        </pre>
                     )}
                </div>
            </div>
        </div>
    );
};

// --- APP PROVIDER & ROUTER ---
const DataProvider = ({ children }: { children: React.ReactNode }) => {
    const [data, setData] = useState<AppData | null>(null);
    const [debugData, setDebugData] = useState<DebugData | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    
    // --- THEME MANAGEMENT ---
    const [theme, setThemeState] = useState<Theme>(() => {
        const storedTheme = localStorage.getItem('pediaQuizTheme') as Theme;
        if (storedTheme) {
            return storedTheme;
        }
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    });

    useEffect(() => {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }, [theme]);

    const setTheme = (newTheme: Theme) => {
        localStorage.setItem('pediaQuizTheme', newTheme);
        setThemeState(newTheme);
    };

    // --- STATE HOOKS ---
    const usePersistentState = <T,>(key: string, defaultValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
        const [state, setState] = useState<T>(() => {
            try {
                const saved = localStorage.getItem(key);
                return saved ? JSON.parse(saved) : defaultValue;
            } catch (e) {
                console.error(`Failed to parse ${key} from localStorage`, e);
                return defaultValue;
            }
        });

        useEffect(() => {
            localStorage.setItem(key, JSON.stringify(state));
        }, [key, state]);

        return [state, setState];
    };
    
    const [bookmarks, setBookmarks] = usePersistentState<string[]>('pediaQuizBookmarks', []);
    const [quizHistory, setQuizHistory] = usePersistentState<QuizResult[]>('pediaQuizHistory', []);
    const [attempted, setAttempted] = usePersistentState<AttemptedMCQs>('pediaQuizAttempted', {});
    
    // --- ACTIONS ---
    const toggleBookmark = (mcqId: string) => {
        setBookmarks(prev => prev.includes(mcqId) ? prev.filter(id => id !== mcqId) : [...prev, mcqId]);
    };

    const addQuizResult = (result: Omit<QuizResult, 'id' | 'date'>) => {
        const newResult: QuizResult = { ...result, id: Date.now().toString(), date: new Date().toISOString() };
        setQuizHistory(prev => [...prev, newResult]);
    };

    const addAttempt = (mcqId: string, isCorrect: boolean) => {
        setAttempted(prev => ({ ...prev, [mcqId]: { isCorrect } }));
    };

    const resetProgress = () => {
        if (window.confirm("Are you sure you want to reset all your progress? This action cannot be undone.")) {
            setBookmarks([]);
            setQuizHistory([]);
            setAttempted({});
            alert("Progress has been reset.");
        }
    };

    const augmentDataWithCounts = (appData: AppData | null): AppData | null => {
        if (!appData) return null;
        const mcqsByChapter = new Map<string, number>();
        appData.mcqs.forEach(mcq => mcqsByChapter.set(mcq.chapterId, (mcqsByChapter.get(mcq.chapterId) || 0) + 1));
        const augmentedTopics = appData.topics.map(topic => {
            let totalMcqCount = 0;
            const augmentedChapters = topic.chapters.map(chapter => {
                const mcqCount = mcqsByChapter.get(chapter.id) || 0;
                totalMcqCount += mcqCount;
                return { ...chapter, mcqCount };
            });
            return { ...topic, chapters: augmentedChapters, chapterCount: topic.chapters.length, totalMcqCount };
        });
        return { ...appData, topics: augmentedTopics };
    };

    const loadAppData = useCallback(async (forceRefresh = false) => {
        setLoading(true); setError(null); if (forceRefresh) clearCache();
        try {
            const cachedData = !forceRefresh ? loadDataFromCache() : null;
            if (cachedData) {
                setData(augmentDataWithCounts(cachedData));
            } else {
                const { processedData, debugData: fetchedDebugData } = await fetchAndProcessData();
                setData(augmentDataWithCounts(processedData));
                setDebugData(fetchedDebugData);
            }
        } catch (e: any) {
            setError(e.message || 'Failed to load data.');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadAppData(); }, [loadAppData]);

    const refreshData = async () => { await loadAppData(true); };

    return (
        <DataContext.Provider value={{ data, debugData, loading, error, refreshData, bookmarks, toggleBookmark, quizHistory, addQuizResult, attempted, addAttempt, theme, setTheme, resetProgress }}>
            {children}
        </DataContext.Provider>
    );
};

const Layout = ({ children }: { children: React.ReactNode }) => (
    <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8 pb-24">
            {children}
        </main>
        <BottomNav />
        <Footer />
    </div>
);

function App() { return ( <DataProvider> <AppContent /> </DataProvider> ); }

const AppContent = () => {
    const { loading, error } = useData();
    return (
        <Layout>
            {loading && <Loader message="Loading PediaQuiz..." />}
            {error && !loading && <div className="text-center py-10 text-red-500">{error}</div>}
            {!loading && !error && (
                <Routes>
                    <Route path="/" element={<DashboardPage />} />
                    <Route path="/chapter/:chapterId" element={<ChapterDetailPage />} />
                    <Route path="/session/:chapterId/:mode" element={<MCQSessionPage />} />
                    <Route path="/bookmarks" element={<BookmarksPage />} />
                    <Route path="/stats" element={<StatsPage />} />
                    <Route path="/settings" element={<SettingsPage />} />
                </Routes>
            )}
        </Layout>
    );
}

export default App;
